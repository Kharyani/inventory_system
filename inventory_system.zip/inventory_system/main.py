import db
import reports

db.create_tables()


def menu():
    print("\n===== INVENTORY MANAGEMENT SYSTEM =====")
    print("1. Add Product")
    print("2. Update Stock")
    print("3. Sell Product")
    print("4. View Inventory")
    print("5. Generate Reports")
    print("6. Delete Product")
    print("7. Exit")


def add_product():
    name = input("Name: ")
    category = input("Category: ")
    price = float(input("Price: "))
    quantity = int(input("Quantity: "))
    supplier = input("Supplier: ")

    if price < 0 or quantity < 0:
        print("Invalid input!")
        return

    db.add_product(name, category, price, quantity, supplier)
    print("Product added successfully!")


def update_stock():
    pid = int(input("Product ID: "))
    qty = int(input("Add Quantity: "))
    db.update_stock(pid, qty)
    print("Stock updated!")


def sell_product():
    pid = int(input("Product ID: "))
    qty = int(input("Quantity Sold: "))

    products = db.get_all_products()
    for p in products:
        if p[0] == pid:
            if p[4] < qty:
                print("Not enough stock!")
                return
            total = qty * p[3]
            db.record_sale(pid, qty, total)
            print("Sale recorded!")
            return

    print("Product not found!")


def view_inventory():
    products = db.get_all_products()
    for p in products:
        print(p)


def generate_reports():
    print("\n--- REPORTS ---")
    print("Total Inventory Value:", reports.inventory_value())
    print("Total Sales:", reports.sales_summary())

    print("\nLow Stock Items:")
    for item in reports.low_stock_alert():
        print(item)

    print("\nBest Selling Products:")
    for item in reports.best_selling_products():
        print(item)


def delete_product():
    pid = int(input("Product ID to delete: "))
    db.delete_product(pid)
    print("Deleted successfully!")


while True:
    menu()
    choice = input("Enter choice: ")

    if choice == "1":
        add_product()
    elif choice == "2":
        update_stock()
    elif choice == "3":
        sell_product()
    elif choice == "4":
        view_inventory()
    elif choice == "5":
        generate_reports()
    elif choice == "6":
        delete_product()
    elif choice == "7":
        break
    else:
        print("Invalid choice!")