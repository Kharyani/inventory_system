import sqlite3

DB_NAME = "inventory.db"

def connect():
    return sqlite3.connect(DB_NAME)


def inventory_value():
    conn = connect()
    cursor = conn.cursor()
    cursor.execute("SELECT SUM(price * quantity) FROM products")
    value = cursor.fetchone()[0]
    conn.close()
    return value or 0


def best_selling_products():
    conn = connect()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT product_id, SUM(quantity) as total_sold
        FROM sales
        GROUP BY product_id
        ORDER BY total_sold DESC
    """)
    data = cursor.fetchall()
    conn.close()
    return data


def low_stock_alert(threshold=5):
    conn = connect()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM products WHERE quantity <= ?", (threshold,))
    data = cursor.fetchall()
    conn.close()
    return data


def sales_summary():
    conn = connect()
    cursor = conn.cursor()
    cursor.execute("SELECT SUM(total_price) FROM sales")
    total = cursor.fetchone()[0]
    conn.close()
    return total or 0