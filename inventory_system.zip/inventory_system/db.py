import sqlite3

DB_NAME = "inventory.db"


def connect():
    return sqlite3.connect(DB_NAME)


def create_tables():
    conn = connect()
    cursor = conn.cursor()

    # Products Table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS products (
        product_id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        category TEXT NOT NULL,
        price REAL NOT NULL,
        quantity INTEGER NOT NULL,
        supplier TEXT NOT NULL
    )
    """)

    # Sales Table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS sales (
        sale_id INTEGER PRIMARY KEY AUTOINCREMENT,
        product_id INTEGER,
        quantity INTEGER,
        total_price REAL,
        date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(product_id) REFERENCES products(product_id)
    )
    """)

    conn.commit()
    conn.close()


# Add Product
def add_product(name, category, price, quantity, supplier):

    if price < 0 or quantity < 0:
        raise ValueError("Price and quantity cannot be negative.")

    conn = connect()
    cursor = conn.cursor()

    cursor.execute("""
    INSERT INTO products (name, category, price, quantity, supplier)
    VALUES (?, ?, ?, ?, ?)
    """, (name, category, price, quantity, supplier))

    conn.commit()
    conn.close()


# Update Stock
def update_stock(product_id, quantity):

    if quantity < 0:
        raise ValueError("Quantity cannot be negative.")

    conn = connect()
    cursor = conn.cursor()

    cursor.execute("""
    UPDATE products
    SET quantity = quantity + ?
    WHERE product_id = ?
    """, (quantity, product_id))

    conn.commit()
    conn.close()


# View All Products
def get_all_products():
    conn = connect()
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM products")
    data = cursor.fetchall()

    conn.close()
    return data


# Case-Insensitive Product Search
def search_product(name):
    conn = connect()
    cursor = conn.cursor()

    cursor.execute("""
    SELECT * FROM products
    WHERE LOWER(name) = LOWER(?)
    """, (name,))

    data = cursor.fetchall()

    conn.close()
    return data


# Reduce Stock
def reduce_stock(product_id, quantity):

    conn = connect()
    cursor = conn.cursor()

    cursor.execute("""
    UPDATE products
    SET quantity = quantity - ?
    WHERE product_id = ?
    """, (quantity, product_id))

    conn.commit()
    conn.close()


# Delete Product
def delete_product(product_id):
    conn = connect()
    cursor = conn.cursor()

    cursor.execute("""
    DELETE FROM products
    WHERE product_id = ?
    """, (product_id,))

    conn.commit()
    conn.close()


# Record Sale (FIXED VERSION)
def record_sale(product_id, quantity, total_price):

    conn = connect()
    cursor = conn.cursor()

    # Insert sale record
    cursor.execute("""
    INSERT INTO sales (product_id, quantity, total_price)
    VALUES (?, ?, ?)
    """, (product_id, quantity, total_price))

    # Reduce stock using SAME connection
    cursor.execute("""
    UPDATE products
    SET quantity = quantity - ?
    WHERE product_id = ?
    """, (quantity, product_id))

    conn.commit()
    conn.close()